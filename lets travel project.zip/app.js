let express = require('express');
let app = express();
let mongoose = require('mongoose');
let Post = require ('./models/posts').Post;
let multer = require('multer');
let path = require('path');

mongoose.connect('mongodb://localhost/travels', { useNewUrlParser: true });
app.use(express.json());
let imageStorage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'public/images'),
    filename: (req, file, cb) => cb(null, file.originalname)
})

app.use(multer({storage: imageStorage}).single('imageFile'));

let id = 1;

// let post1 = new Post({
//     id: 2,
//     title: 'Thank U God',
//     date: new Date(),
//     description: 'some text',
//     text: 'Some text',
//     country: 'India',
//     imageURL: '/images/1.jpg',
// });

// post1.save();

app.get('/posts', async (req, resp)=>{
    let posts = await Post.find();
    resp.send(posts);
})
app.post('/posts', async (req, resp)=>{
    let reqBody = req.body;
    let imgPath;
    if(reqBody.imageURL){
        imgPath = reqBody.imageURL;
    } else{
        imgPath = req.file.path.substring(req.file.path.indexOf(path.sep), req.file.path.length);
    }

    let newPost  = new Post({
        id: id++,
        title: reqBody.title,
        date: new Date(),
        description: reqBody.description,
        text: reqBody.text,
        country: reqBody.country,
        imageURL: imgPath
    })
    // console.log(req.file);
    await newPost.save();
    resp.send('Created')
})



app.use(express.static('public'));

app.listen(3000, ()=> console.log('Listening 3000...'));